# Composite search findings — Andre Moten Replit apps

**Search date:** Wed Sep 23, 2026 (America/Chicago)  
**Method:** user-replit MCP `list_app_files` + `read_app_file` only (no browser, no ask_question)  
**Query:** path/filename or content containing `composite` (case-insensitive), plus related credit/score/wealth/passport peeks

**There is no Replit app titled "Composite."** Searched the five editable apps listed below.

---

## Summary

| App | replId | Filename matches | Content matches | Files saved locally |
|-----|--------|------------------|-----------------|---------------------|
| Treasure KC (1) | e9087c86-ba43-4ca3-8106-5c4c8e62ea41 | **0** | **3** (+2 related docs) | 5 |
| Luxury Finance Hub | 58fcf3f4-701e-4e83-bc3f-d5c6d773ba9f | **0** | **0** | 0 |
| Treasure Network | 3dd49bc9-078a-481b-8b96-51d92ca4cd1d | **0** | **0** | 0 |
| Voice Actor Lookup | ee66949d-6c3b-4be9-82f1-da93af6433d0 | **0** | **1** (TypeScript only) | 1 |
| Treasure KC | cb8604ed-3458-4979-ab72-fec409da498d | **0** | **0** | 0 |

**Total local copies under `/workspace/replit-composite/`:** 6 artifact files + this FINDINGS.md  
**No file or folder was named `composite*` / `Composite*` / `compositeScore*` in any of the five apps.**

---

## Matches (detail)

### 1. Treasure KC (1) — `GROK_ENGINE_BREAKDOWN.md`

| Field | Value |
|-------|-------|
| App title | Treasure KC (1) |
| replId | e9087c86-ba43-4ca3-8106-5c4c8e62ea41 |
| Original path | `GROK_ENGINE_BREAKDOWN.md` |
| Local save | `/workspace/replit-composite/Treasure-KC-1/GROK_ENGINE_BREAKDOWN.md` |
| Match type | **Content** (4 hits) |
| Hits | "Composite score blends…" (Hood Heat); `riskScore` (composite); `getSupplyStats()` — composite snapshot; `getNeighborhoodImpactData` — composite per-ZIP snapshot |

### 2. Treasure KC (1) — `server/financial-health-intel.ts`

| Field | Value |
|-------|-------|
| App title | Treasure KC (1) |
| replId | e9087c86-ba43-4ca3-8106-5c4c8e62ea41 |
| Original path | `server/financial-health-intel.ts` |
| Local save | `/workspace/replit-composite/Treasure-KC-1/server/financial-health-intel.ts` (full copy) |
| Match type | **Content** |
| Hit | Comment: `Composite "financial strength"` → buyer-facing `strengthIndex` (avg of `financial_health_score`) |

This is the clearest **financial/credit-adjacent composite** in the account.

### 3. Treasure KC (1) — `server/behavioral-lending.ts`

| Field | Value |
|-------|-------|
| App title | Treasure KC (1) |
| replId | e9087c86-ba43-4ca3-8106-5c4c8e62ea41 |
| Original path | `server/behavioral-lending.ts` |
| Local save | `/workspace/replit-composite/Treasure-KC-1/server/behavioral-lending.COMPOSITE-EXCERPT.ts` |
| Match type | **Content** |
| Hit | API docs for `/lending-signal/:zipCode`: *"a single composite index (0-100)"* |
| Note | Full file fit under 100KB and was read; local copy is an excerpt preserving the match (full file lives on Replit). |

### 4. Voice Actor Lookup — `replit.md`

| Field | Value |
|-------|-------|
| App title | Voice Actor Lookup |
| replId | ee66949d-6c3b-4be9-82f1-da93af6433d0 |
| Original path | `replit.md` |
| Local save | `/workspace/replit-composite/Voice-Actor-Lookup/replit.md` |
| Match type | **Content** (non-financial) |
| Hit | Section **"TypeScript & Composite Projects"** / `composite: true` (TS project references). **Not** a financial/credit composite. |

### Related (no literal "composite" in source; documented as composite in GROK)

| Original | Local | Reason |
|----------|-------|--------|
| `server/hood-heat-index.ts` | `…/server/hood-heat-index.RELATED.md` | GROK: "Composite score blends" for Hood Heat |
| `server/neighborhood-impact.ts` | `…/server/neighborhood-impact.RELATED.md` | GROK: "composite per-ZIP snapshot" |

Also peeked (no "composite" in content): `wealth-passport-matrix.ts`, `passport-score-floor.ts`, `wealth-passport-intake.ts`, `wealth-consistency.ts`, `wealth-passport-xgboost.ts`, `credit-builder.tsx`, `behavioral-credit.tsx`, `methodology.tsx`, LFH `WealthPassport.tsx` / `ProveConsistency.tsx` / `siteContent.ts` / `engineRoutes.ts`, `replit.md` (TKC1 + LFH + TN), `SYSTEM_AUDIT` / engine audit (no literal composite), `tkc-rewards.ts` (no literal; GROK calls `getSupplyStats` a composite snapshot).  
`server/wealth-passport.ts` was **too large** for `read_app_file` (>100KB) — could not content-search; no filename match.

---

## Apps with zero composite matches — top-level listings

### Luxury Finance Hub (`58fcf3f4-701e-4e83-bc3f-d5c6d773ba9f`)
`.agents/`, `.gitignore`, `.replit`, `attached_assets/`, `client/`, `components.json`, `drizzle.config.ts`, `mint-token.js`, `package-lock.json`, `package.json`, `postcss.config.js`, `replit.md`, `replit.nix`, `screenshots/`, `script/`, `scripts/`, `seo_strategy.md`, `server/`, `shared/`, `tailwind.config.ts`, `tsconfig.json`, `vite.config.ts`

### Treasure Network (`3dd49bc9-078a-481b-8b96-51d92ca4cd1d`)
`.agents/`, `.gitignore`, `.replit`, `.replitignore`, `artifacts/`, `attached_assets/`, `docs/`, `lib/`, `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `README.md`, `replit.md`, `scripts/`, `threat_model.md`, `tsconfig.base.json`, `tsconfig.json`

### Treasure KC (`cb8604ed-3458-4979-ab72-fec409da498d`) — older/smaller sibling
`.agents/`, `.gitignore`, `.replit`, `attached_assets/`, `client/`, `components.json`, `drizzle.config.ts`, `final.png`, `logs/`, `package-lock.json`, `package.json`, `postcss.config.js`, `references/`, `replit.md`, `script/`, `scripts/`, `server/`, `shared/`, `SYSTEM_AUDIT.md`, `tailwind.config.ts`, `tsconfig.json`, `uploads/`, `user_export.json`, `vite.config.ts`, `XXWN3kkv`  
(No `financial-health-intel.ts` / `behavioral-lending.ts` / `GROK_ENGINE_BREAKDOWN.md` in this app.)

### Treasure KC (1) top-level (for completeness)
`.agents/`, `.gitignore`, `.replit`, `attached_assets/`, `B2B_GO_LIVE.md`, `changes.diff`, `client/`, `components.json`, `docs/`, `drizzle.config.ts`, `final.png`, `GROK_ENGINE_BREAKDOWN.md`, `index.js`, `app.js`, `legal/`, `logs/`, `package-lock.json`, `package.json`, `postcss.config.js`, `public/`, `pyproject.toml`, `receipt-vault/`, `references/`, `replit.md`, `replit.nix`, `screenshots/`, `script/`, `scripts/`, `server/`, `shared/`, `SYSTEM_AUDIT.md`, `tailwind.config.ts`, `threat_model.md`, `TKC_SYSTEM_MANUAL.md`, `tsconfig.json`, `uploads/`, `uv.lock`, `vite.config.ts`

### Voice Actor Lookup top-level
`.agents/`, `.gitignore`, `.replit`, `.replitignore`, `artifacts/`, `attached_assets/`, `lib/`, `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `replit.md`, `scripts/`, `tsconfig.base.json`, `tsconfig.json`

---

## Voice-ready inventory (for parent agent)

- **4 content matches** across 2 apps; **0 filename matches** anywhere.  
- **Financial composites live only in Treasure KC (1):**  
  1. `financial-health-intel.ts` — Composite financial strength / strengthIndex  
  2. `behavioral-lending.ts` — composite lending-signal index (0–100)  
  3. `GROK_ENGINE_BREAKDOWN.md` — documents several engines as “composite”  
- **Voice Actor Lookup** only has TypeScript `composite: true` project config jargon.  
- Luxury Finance Hub, Treasure Network, and older Treasure KC: **nothing**.  
- Local tree: `/workspace/replit-composite/` with `FINDINGS.md` + copies under `Treasure-KC-1/` and `Voice-Actor-Lookup/`.
