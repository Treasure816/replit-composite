// Financial Health Intelligence Engine
// ─────────────────────────────────────────────────────────────────────────────
// Turns the 5-question Wealth Passport intake answers into a sellable
// B2B intelligence product. Aggregates anonymously by ZIP code (and
// platform-wide) with k-anonymity suppression so individual members are
// never identifiable.
//
// Buyers (banks, credit unions, fintechs, lenders, CDFIs, city) pay for
// ZIP-level signals like:
//   - banked %                  → bank acquisition targeting
//   - balance-check frequency   → fintech engagement market sizing
//   - on-time bill pay %        → lender underwriting signal
//   - windfall behavior         → savings-product / debt-product fit
//   - money confidence          → financial-literacy program targeting
//
// Language law: never use "score" / "credit" in any user/buyer-facing
// label or response field. Internal SQL columns may keep historical names.

import { db } from "./db";
import { sql } from "drizzle-orm";

const K_ANON_THRESHOLD = 10;

function suppress(value: number | null | undefined): number | null {
  const n = Number(value || 0);
  return n >= K_ANON_THRESHOLD ? n : null;
}
function pct(num: number, denom: number): number | null {
  if (denom < K_ANON_THRESHOLD) return null;
  return Math.round((num / denom) * 1000) / 10; // 1-decimal percent
}

export interface ZipFinancialHealth {
  zip: string;
  respondents: number | null;       // null when below k-threshold
  bankedPercent: number | null;
  balanceCheckMix: {
    never: number | null;
    onceTwice: number | null;
    weekly: number | null;
    daily: number | null;
  };
  onTimeBillPayPercent: number | null;     // always + usually
  billPayMix: {
    always: number | null;
    usually: number | null;
    sometimes: number | null;
    rarely: number | null;
  };
  windfallMix: {
    save: number | null;
    payBills: number | null;
    helpFamily: number | null;
    spend: number | null;
  };
  confidenceMix: {
    notConfident: number | null;
    somewhat: number | null;
    veryConfident: number | null;
  };
  // Composite "financial strength" — average of the financial_health_score
  // column already computed per intake. Buyer-facing label is "strength
  // index", never "score".
  strengthIndex: number | null;
  asOf: string;
}

const EMPTY = (zip: string): ZipFinancialHealth => ({
  zip,
  respondents: null,
  bankedPercent: null,
  balanceCheckMix: { never: null, onceTwice: null, weekly: null, daily: null },
  onTimeBillPayPercent: null,
  billPayMix: { always: null, usually: null, sometimes: null, rarely: null },
  windfallMix: { save: null, payBills: null, helpFamily: null, spend: null },
  confidenceMix: { notConfident: null, somewhat: null, veryConfident: null },
  strengthIndex: null,
  asOf: new Date().toISOString(),
});

// Pull the latest intake per user (members re-take every 90 days; only the
// most recent answers represent current state) and aggregate by ZIP.
export async function getFinancialHealthForZip(zip: string): Promise<ZipFinancialHealth> {
  const result = await db.execute(sql`
    WITH latest AS (
      SELECT DISTINCT ON (i.user_id)
        i.user_id, i.has_bank_account, i.balance_check_frequency,
        i.bill_pay_consistency, i.unexpected_money_habit, i.money_confidence,
        i.financial_health_score
      FROM wealth_passport_intakes i
      JOIN users u ON u.id = i.user_id
      WHERE u.zip_code = ${zip}
      ORDER BY i.user_id, i.completed_at DESC
    )
    SELECT
      COUNT(*)::int AS respondents,
      SUM(CASE WHEN has_bank_account THEN 1 ELSE 0 END)::int AS banked,
      SUM(CASE WHEN balance_check_frequency = 'never' THEN 1 ELSE 0 END)::int AS bf_never,
      SUM(CASE WHEN balance_check_frequency = 'once_twice' THEN 1 ELSE 0 END)::int AS bf_once_twice,
      SUM(CASE WHEN balance_check_frequency = 'weekly' THEN 1 ELSE 0 END)::int AS bf_weekly,
      SUM(CASE WHEN balance_check_frequency = 'daily' THEN 1 ELSE 0 END)::int AS bf_daily,
      SUM(CASE WHEN bill_pay_consistency = 'always' THEN 1 ELSE 0 END)::int AS bp_always,
      SUM(CASE WHEN bill_pay_consistency = 'usually' THEN 1 ELSE 0 END)::int AS bp_usually,
      SUM(CASE WHEN bill_pay_consistency = 'sometimes' THEN 1 ELSE 0 END)::int AS bp_sometimes,
      SUM(CASE WHEN bill_pay_consistency = 'rarely' THEN 1 ELSE 0 END)::int AS bp_rarely,
      SUM(CASE WHEN unexpected_money_habit = 'save' THEN 1 ELSE 0 END)::int AS w_save,
      SUM(CASE WHEN unexpected_money_habit = 'pay_bills' THEN 1 ELSE 0 END)::int AS w_bills,
      SUM(CASE WHEN unexpected_money_habit = 'help_family' THEN 1 ELSE 0 END)::int AS w_family,
      SUM(CASE WHEN unexpected_money_habit = 'spend' THEN 1 ELSE 0 END)::int AS w_spend,
      SUM(CASE WHEN money_confidence = 'not_confident' THEN 1 ELSE 0 END)::int AS c_not,
      SUM(CASE WHEN money_confidence = 'somewhat' THEN 1 ELSE 0 END)::int AS c_some,
      SUM(CASE WHEN money_confidence = 'very_confident' THEN 1 ELSE 0 END)::int AS c_very,
      COALESCE(AVG(financial_health_score), 0)::float AS avg_strength
    FROM latest
  `);
  const rows = Array.isArray(result) ? result : (result as { rows?: any[] }).rows || [];
  const r = rows[0];
  if (!r) return EMPTY(zip);
  const n = Number(r.respondents || 0);
  if (n < K_ANON_THRESHOLD) return EMPTY(zip);
  return {
    zip,
    respondents: n,
    bankedPercent: pct(Number(r.banked || 0), n),
    balanceCheckMix: {
      never: pct(Number(r.bf_never || 0), n),
      onceTwice: pct(Number(r.bf_once_twice || 0), n),
      weekly: pct(Number(r.bf_weekly || 0), n),
      daily: pct(Number(r.bf_daily || 0), n),
    },
    onTimeBillPayPercent: pct(Number(r.bp_always || 0) + Number(r.bp_usually || 0), n),
    billPayMix: {
      always: pct(Number(r.bp_always || 0), n),
      usually: pct(Number(r.bp_usually || 0), n),
      sometimes: pct(Number(r.bp_sometimes || 0), n),
      rarely: pct(Number(r.bp_rarely || 0), n),
    },
    windfallMix: {
      save: pct(Number(r.w_save || 0), n),
      payBills: pct(Number(r.w_bills || 0), n),
      helpFamily: pct(Number(r.w_family || 0), n),
      spend: pct(Number(r.w_spend || 0), n),
    },
    confidenceMix: {
      notConfident: pct(Number(r.c_not || 0), n),
      somewhat: pct(Number(r.c_some || 0), n),
      veryConfident: pct(Number(r.c_very || 0), n),
    },
    strengthIndex: Math.round(Number(r.avg_strength || 0) * 10) / 10,
    asOf: new Date().toISOString(),
  };
}

// Bulk: every ZIP that has at least k respondents.
export async function getFinancialHealthAllZips(): Promise<{
  asOf: string;
  zipsCovered: number;
  totalRespondents: number;
  zips: ZipFinancialHealth[];
}> {
  const result = await db.execute(sql`
    WITH latest AS (
      SELECT DISTINCT ON (i.user_id)
        u.zip_code, i.has_bank_account, i.balance_check_frequency,
        i.bill_pay_consistency, i.unexpected_money_habit, i.money_confidence,
        i.financial_health_score, i.user_id
      FROM wealth_passport_intakes i
      JOIN users u ON u.id = i.user_id
      WHERE u.zip_code IS NOT NULL AND length(u.zip_code) >= 5
      ORDER BY i.user_id, i.completed_at DESC
    )
    SELECT zip_code FROM latest GROUP BY zip_code HAVING COUNT(*) >= ${K_ANON_THRESHOLD}
  `);
  const rows = Array.isArray(result) ? result : (result as { rows?: any[] }).rows || [];
  const zips = rows.map((r: any) => String(r.zip_code).slice(0, 5));
  const data = await Promise.all(zips.map((z) => getFinancialHealthForZip(z)));
  const totalRespondents = data.reduce((sum, d) => sum + (d.respondents || 0), 0);
  return {
    asOf: new Date().toISOString(),
    zipsCovered: data.length,
    totalRespondents,
    zips: data,
  };
}

// Platform-wide rollup (admin dashboard). No ZIP filter, no k-suppression
// at the platform level (admin sees raw totals; only buyer-facing per-ZIP
// is k-suppressed).
export async function getFinancialHealthPlatformOverview(): Promise<{
  totalRespondents: number;
  bankedPercent: number;
  onTimeBillPayPercent: number;
  unbankedCount: number;
  topNeedHelp: { confidence: "not_confident"; count: number };
  zipsWithKAnonCoverage: number;
  asOf: string;
}> {
  const result = await db.execute(sql`
    WITH latest AS (
      SELECT DISTINCT ON (user_id)
        user_id, has_bank_account, bill_pay_consistency, money_confidence
      FROM wealth_passport_intakes
      ORDER BY user_id, completed_at DESC
    )
    SELECT
      COUNT(*)::int AS total,
      SUM(CASE WHEN has_bank_account THEN 1 ELSE 0 END)::int AS banked,
      SUM(CASE WHEN bill_pay_consistency IN ('always','usually') THEN 1 ELSE 0 END)::int AS on_time,
      SUM(CASE WHEN NOT has_bank_account THEN 1 ELSE 0 END)::int AS unbanked,
      SUM(CASE WHEN money_confidence = 'not_confident' THEN 1 ELSE 0 END)::int AS need_help
    FROM latest
  `);
  const rows = Array.isArray(result) ? result : (result as { rows?: any[] }).rows || [];
  const r = rows[0] || {};
  const total = Number(r.total || 0);

  const zipResult = await db.execute(sql`
    WITH latest AS (
      SELECT DISTINCT ON (i.user_id) u.zip_code, i.user_id
      FROM wealth_passport_intakes i
      JOIN users u ON u.id = i.user_id
      WHERE u.zip_code IS NOT NULL
      ORDER BY i.user_id, i.completed_at DESC
    )
    SELECT COUNT(*)::int AS zips
    FROM (SELECT zip_code FROM latest GROUP BY zip_code HAVING COUNT(*) >= ${K_ANON_THRESHOLD}) z
  `);
  const zipRows = Array.isArray(zipResult) ? zipResult : (zipResult as { rows?: any[] }).rows || [];
  const zipsCovered = Number(zipRows[0]?.zips || 0);

  return {
    totalRespondents: total,
    bankedPercent: total > 0 ? Math.round((Number(r.banked || 0) / total) * 1000) / 10 : 0,
    onTimeBillPayPercent: total > 0 ? Math.round((Number(r.on_time || 0) / total) * 1000) / 10 : 0,
    unbankedCount: Number(r.unbanked || 0),
    topNeedHelp: { confidence: "not_confident", count: Number(r.need_help || 0) },
    zipsWithKAnonCoverage: zipsCovered,
    asOf: new Date().toISOString(),
  };
}
