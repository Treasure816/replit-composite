/**
 * EXCERPT COPY from Treasure KC (1) server/behavioral-lending.ts
 * Full file read via user-replit read_app_file (≤100KB, succeeded).
 * Match reason: CONTENT contains the word "composite".
 * Exact hit (getApiDocumentation → /lending-signal/:zipCode):
 *
 *   description: "Lending risk signal — a single composite index (0-100) with
 *   risk category and CRA-ready recommendation. Designed for loan officers
 *   and automated underwriting."
 *
 * Replit path: server/behavioral-lending.ts
 * replId: e9087c86-ba43-4ca3-8106-5c4c8e62ea41
 * App: Treasure KC (1)
 *
 * Below: the matching endpoint documentation block from getApiDocumentation().
 */

export function getApiDocumentation_COMPOSITE_EXCERPT() {
  return {
    endpoints: [
      {
        path: "/lending-signal/:zipCode",
        method: "GET",
        scope: "zip-behavioral",
        description: "Lending risk signal — a single composite index (0-100) with risk category and CRA-ready recommendation. Designed for loan officers and automated underwriting.",
        sampleResponse: {
          zipCode: "64108",
          kAnonymitySatisfied: true,
          riskScore: 78.3,
          riskCategory: "low",
          avgBehaviorScore: 73.2,
          communityRetention: 89.4,
          financialLiteracy: 67.8,
          communityInvestment: 34.2,
          rippleEffect: 1.8,
          recommendation: "Strong behavioral signals. Favorable for CRA-eligible lending.",
          dataHash: "a1b2c3d4e5f6...",
          craCompliance: { standard: "CRA", auditTrail: "XRP Ledger (mainnet)" },
        },
      },
    ],
  };
}

// File also exports: checkLendingEligibility, submitLoanApplication,
// generateZipBehavioralReport, getUpliftIndex, authenticateCdfiApiKey,
// getLendingDashboardStats, PARTNER_PRICING, buildCraComplianceBlock,
// logB2bApiCallToXrpl, generateLendingAIInsight, etc.
