# RELATED (no literal "composite" in this source file)

App: Treasure KC (1)
replId: e9087c86-ba43-4ca3-8106-5c4c8e62ea41
Original path: server/hood-heat-index.ts

Why related: GROK_ENGINE_BREAKDOWN.md documents Hood Heat as:
  "Composite score blends: scout_activity, check_in_velocity (last 7d),
   referral_chains, passport_evolution, ripple_multiplier"

The implementation computes `heatScore` as a weighted sum of scout /
check-in / referral / member / merchant counts (HEAT_WEIGHTS). The source
file itself does NOT contain the string "composite".

Open on Replit for the full file. Key symbols: getHoodHeatIndex,
HEAT_WEIGHTS, heatScore, getPassportEvolution, getScoutGPSChainMap.
