# RELATED (no literal "composite" in this source file)

App: Treasure KC (1)
replId: e9087c86-ba43-4ca3-8106-5c4c8e62ea41
Original path: server/neighborhood-impact.ts

Why related: GROK_ENGINE_BREAKDOWN.md documents:
  "getNeighborhoodImpactData(forceRefresh) — composite per-ZIP snapshot"

Source builds per-ZIP check-in / member / merchant aggregates. No literal
"composite" string in the file.
