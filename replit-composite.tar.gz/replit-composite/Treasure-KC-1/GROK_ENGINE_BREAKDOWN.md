# Treasure KC — All 29 Intelligence Engines: Complete Build Breakdown
**Paste this entire file into Grok for full-context analysis. Source of truth: `server/engine-health.ts`.**

Every engine below shows: **what it does** in plain English → **how it's built** (file, tables, algorithm, AI) → **what it outputs** → **who buys it and price** → **WebSocket channel**.

The 29 engines split into **19 canonical "Moten-19"** (flagged `canonical: true` in `engine-health.ts`) and **10 extended** added through May 2026. **All 29 are documented in this file** — sections `### 1` through `### 29`. The breakdown is split into two parts: "CANONICAL MOTEN-19 (engines 1–19)" below, then "EXTENDED ENGINES (engines 20–29)".

---

## CANONICAL MOTEN-19 (engines 1–19)

---

### 1. Ripple Engine — `ripple-engine`
**What it does**: Quantifies the viral, cascading impact of every member action across the community. When one person checks in, refers a friend, completes a quiz, or scouts a spot, the engine measures the multiplier that one action creates as it ripples through the chain.
**Build**:
- File: `server/ripple-engine.ts` (36 KB)
- Core algorithm: `calcRippleTransaction(userId, actionType, passportScore, chainDepth, streakDays)`
- Action base values (hardcoded in `ACTION_BASE_RIPPLE`): scout_report 1.5, check_in 0.8, referral 2.0, quiz_complete 1.2, donation 3.0, trading 1.4, volunteer 1.8, voting 1.0
- Chain-depth weights amplify viral chains: scout_report ×2.5, referral ×3.0, donation ×1.5
- Streak bonuses: 3d ×1.1 → 7d ×1.25 → 14d ×1.4 → 30d ×1.6 → 60d ×1.8 → 90d ×2.0
- Velocity boost (`applyVelocityBoost`) lets admin push global multiplier up for a window (default 72h)
- Anomaly detection: `ANOMALY_VELOCITY_THRESHOLD = 10` flags suspicious bursts
- Anonymization via `anonLabel()` for export
- Audit trail (`getRippleAuditTrail`) + CSV export (`exportRippleCSV`) + AI-generated insight (`generateRippleEngineAIInsight`)
**Tables**: `users`, `check_ins`, `scout_submissions`, `referrals`, `donations`, `quiz_scores`, `wealth_passports`
**Output**: `{ totalRipple, topZips, perActionBreakdown, scoutChainLog }`
**WebSocket**: `ripple` (30s)
**Buyer**: Civic foundations, growth strategists. Cost: bundled in Strategic packages.

---

### 2. Ripple Forecast — `ripple-forecast`
**What it does**: Predicts the next 7 days of ripple growth — projected viral coefficient, momentum tier (surging / rising / steady / cooling), and per-ZIP forecast.
**Build**:
- File: `server/ripple-forecast-api.ts`
- Cached pulse (25s TTL) → `buildRippleForecastPulse()` recomputes
- SHA-256 XRPL hash on every snapshot for tamper-proofing (`xrplHash()`)
- K-anonymity guard: `anonymizeIfSmall(arr, k=10)` blanks any cohort below 10 members
- Calculates: `viral_coefficient = referrals / active_users_30d`, `momentum` based on 7d trend slope
- `getZipForecast(zip)` for single-ZIP drill-down
**Tables**: `users`, `referrals`, `check_ins`, `scout_submissions`, `wealth_passports`
**Output**: `{ viral_coefficient, momentum, zips_tracked, top_scenarios[], platform_totals, alerts[] }`
**WebSocket**: `ripple-forecast` (broadcaster start/stop in `startRippleForecastBroadcaster`)
**Buyer**: Growth strategists, VCs. Price: $3,500/mo equivalent.

---

### 3. Ghost Spot Radar — `ghost-spot-radar`
**What it does**: Real-time map of vacant lots, abandoned buildings, dangerous intersections, illegal dumping, broken streetlights — every "ghost spot" reported by Scout Army members and AI-validated.
**Build**:
- File: `server/ghost-spot-radar.ts`
- 16 spot types in `GHOST_SPOT_TYPES`: empty_lot, abandoned_building, popup_vendor, vacant_storefront, construction_site, cracked_sidewalk, pothole, high_grass, downed_powerline, illegal_dumping, broken_streetlight, graffiti, flooding_drainage, damaged_fence, dangerous_intersection, other_issue
- `GHOST_SPOT_RULES` defines bounty TKC + duplicate-radius per type
- `createGhostSpot(submissionId, spotType)` — promoted from a scout submission once vision-AI validates the photo
- `checkGhostSpotDuplicate(lat, lng)` enforces a per-type radius dedupe
- `reviewGhostSpot(id, action, reviewerId)` — admin approve/reject; approval pays a TKC bounty
- `getScoutGhostSpotCount(userId, month)` for monthly cap
- AI insight via `generateGhostSpotAIInsight()` (Grok)
**Tables**: `ghost_spots`, `scout_submissions`, `scout_bounties`
**Output**: `{ totalSpots, pendingSpots, approvedSpots, hotZips[], typeBreakdown }`
**WebSocket**: `ghost-spot` (30s)
**Buyer**: Real estate developers, civic mapping orgs, city public-works. Cost: per-package.

---

### 4. Hood Heat Index — `hood-heat`
**What it does**: Per-ZIP "heat" score combining scout activity, check-in velocity, referral chains, passport growth, and economic flow. Tells you which neighborhoods are on fire vs. cooling.
**Build**:
- File: `server/hood-heat-index.ts`
- `getHoodHeatIndex(targetZip?)` — returns array of `HoodHeatZip` ranked by heat
- Composite score blends: scout_activity, check_in_velocity (last 7d), referral_chains, passport_evolution, ripple_multiplier
- Anonymized via `anonLabel`
- `getPassportEvolution(userId)` shows per-user trajectory
- `getScoutGPSChainMap()` — geo-clustered scout chains
- Broadcaster (`startHoodHeatBroadcaster`) + Grok AI insight + CSV export
**Tables**: `users`, `check_ins`, `scout_submissions`, `referrals`, `wealth_passports`
**Output**: Array of `{ zip, heatScore, scoutActivity, checkInVelocity, referralChains, … }`
**WebSocket**: `hood-heat` (30s)
**Buyer**: City planners, EDCs, retail site-selection. Cost: package-based.

---

### 5. KC Economic Echo — `kc-economic-echo`
**What it does**: Traces every economic "echo" — the multiplier effect of a single dollar through the local KC economy. Member checks in at a coffee shop → coffee shop tips a barista → barista buys lunch at another local merchant → echo-depth = 3.
**Build**:
- File: `server/kc-economic-echo.ts`
- `traceEconomicEcho(userId?, limit=20)` — walks check_ins → merchants → linked offers → downstream activity
- Computes: `cashFlowMultiplier`, `echoDepth`, `localCirculationIndex`, `economicLeakageRate`
- CDFI-grade metrics: `avgDollarMultiplier`, `communityReinvestmentRate`, `topCirculationZips`
- Anonymized actor names (`anonLabel`)
- Broadcaster + Grok AI narrative
**Tables**: `check_ins`, `merchants`, `users`, `tkc_transactions`, `donations`
**Output**: `{ platformEchos, avgCashFlowMultiplier, recentEchos[], topMultipliers[], cdfiMetrics }`
**WebSocket**: `economic-echo` (30s)
**Buyer**: Economic Development Councils (EDCs), CDFIs. Cost: $5,000/mo tier.

---

### 6. Block Loyalty Index — `block-loyalty`
**What it does**: Per-ZIP "stickiness" grade — how loyal members are to their neighborhood merchants. Measures avg check-in days/month, retention, churn, and per-merchant loyalty.
**Build**:
- File: `server/block-loyalty-index.ts`
- `getBlockLoyaltyIndex(targetZip?)` returns `BlockLoyaltyReport`
- `gradeStickiness(score)`: A+ ≥90, A ≥75, B ≥55, C ≥35, D ≥15, F <15
- Computes: `avgCheckInDaysPerMonth`, `medianCheckInDaysPerMonth`, `stickinessScore`, `churnRate30d`, `retentionRate90d`, `avgStreakDays`
- `merchantStickiness[]` — per-merchant loyalty within ZIP
- `insurerMetrics`: low-churn ZIPs, high-retention ZIPs, risk tier (low/medium/high) — sold to insurers as a community-stability signal
- Grok AI insight + CSV export
**Tables**: `users`, `check_ins`, `merchants`
**Output**: Stickiness grades A+ through F, per-ZIP rankings, insurer risk tier
**WebSocket**: `block-loyalty` (30s)
**Buyer**: Insurers, community banks. Cost: $4,000/mo tier.

---

### 7. Legacy Vault — `legacy-vault`
**What it does**: Long-term anchor-resident footprint — the cumulative legacy each member is building (years on platform, total check-ins, referrals, scout submissions, civic votes). Sells to civic orgs that want to recognize and fund "anchor residents."
**Build**:
- File: `server/legacy-vault-api.ts`
- `buildVaultLivePulse()` — aggregates lifetime totals per ZIP + active 30d members
- `getVaultZip(zip)` — single-ZIP detail
- `simulateGrant(zip)` — projects what a grant deployed to that ZIP would activate
- Broadcaster (`startVaultBroadcaster`)
**Tables**: `users`, `check_ins`, `referrals`, `scout_submissions`, `votes`, `wealth_passports`
**Output**: `{ total_members, active_members_30d, zips_tracked, totals: { check_ins, referrals, scouts } }`
**WebSocket**: `legacy-vault` (30s)
**Buyer**: Civic foundations, mayoral grant offices. Cost: package-based.

---

### 8. Flow Predictor — `flow-predictor`
**What it does**: 30-day forecast of where investment, infrastructure, and merchant gaps will pay off. Generates predictions per ZIP across 5 categories: infrastructure, business_investment, safety, community_program, merchant_gap.
**Build**:
- File: `server/flow-predictor.ts`
- `generateFlowPredictions(targetZip?)` — runs heuristic blend over `ZipFlowData`
- Inputs per ZIP: activeMembers, scoutTotal, scoutApproved, scoutRecent, checkinTotal, checkinRecent, checkinWeek, referralTotal, referralRecent, merchantCount, avg wealth_score, literacy_rate, social_velocity
- Each prediction returns: `estimatedInvestment`, `projectedROI`, `confidenceScore` (0-100), `confidenceLabel` (high/medium/low), `timeframeMonths`, `actionableInsight`, `communityImpact`, `votingEligible` flag
- `getFlowSummary()` rolls up total predictions, total projected investment, avg ROI, top ZIPs
- Grok AI insight via `generateFlowPredictorAIInsight`
**Tables**: `users`, `check_ins`, `scout_submissions`, `referrals`, `wealth_passports`, `quiz_scores`, `merchants`
**Output**: Array of forecast predictions with ROI, confidence, and voting eligibility
**WebSocket**: `flow-predictor` (30s)
**Buyer**: CRE investors, city budget offices. Cost: $5,000/mo tier.

---

### 9. Behavioral Lending — `behavioral-lending`
**What it does**: Behavioral credit-scoring engine — lets CDFIs and lenders underwrite loans based on platform behavior (consistency, civic engagement, financial literacy, neighborhood activity) instead of FICO alone. Includes a CDFI-facing API.
**Build**:
- File: `server/behavioral-lending.ts`
- `checkLendingEligibility(userId)` — gates by passport score, streaks, completion of literacy modules
- `submitLoanApplication()` / `updateLoanStatus()` — full LOS pipeline
- `generateZipBehavioralReport(zipCode)` — aggregate ZIP risk profile for lenders
- `getUpliftIndex(zipCode, periods)` — measures behavioral improvement over time (CRA-grade)
- `generateCdfiApiKey()` + `authenticateCdfiApiKey()` — sha256-hashed API keys for CDFI partners
- `PARTNER_PRICING`: tiered annual contracts + daily query caps
- `buildCraComplianceBlock(zipCode, dataHash, endpoint)` — emits CRA-compliant audit blocks
- `logB2bApiCallToXrpl()` — every API call logged on-chain for tamper-proof audit
- Public API documentation via `getApiDocumentation()`
**Tables**: `users`, `loan_applications`, `wealth_passports`, `check_ins`, `cdfi_api_keys`, `cdfi_api_usage`
**Output**: `{ totalApplications, pending, approved, funded, totalVolume, defaultRate, activePartners, activeProducts, totalApiQueries }`
**WebSocket**: `lending` (30s)
**Buyer**: CDFIs, community banks, fintechs. **Pricing**: pilot/launch buyers start at reduced introductory rates; published rate-card range is $25K–$75K/yr per partner once data volume is verified at scale. Specific terms negotiated per buyer.

---

### 10. Churn Prediction — `churn-prediction`
**What it does**: Identifies paid members at risk of churning before their renewal date. Returns a prioritized queue with risk scores so retention team can intervene.
**Build**:
- File: `server/churn-prediction.ts`
- `getChurnQueue()` — only scans `membershipTier IN ('base', 'navigator_plus')` (paid members)
- Per-user signals computed: `daysSinceLastCheckin`, `daysSinceLastQuiz`, `daysUntilRenewal`, `checkinsLast30`, `checkinsPrev30`
- `trendDirection`: declining if `checkinsLast30 < checkinsPrev30 * 0.5`, growing if `> 1.2x`, else stable
- `riskLevel`: low/medium/high/critical based on `riskScore` (composite)
- `recommendation` text per member (e.g., "Send re-engagement email — last check-in 21d ago")
- AI insight via `generateChurnAIInsight` (Grok)
**Tables**: `users`, `check_ins`, `quiz_scores`
**Output**: Array of `ChurnRiskMember` sorted by risk
**WebSocket**: `churn` (30s)
**Buyer**: Internal retention team + sold as a package to subscription-based partner businesses. Cost: $2,500/mo tier.

---

### 11. Merchant Health — `merchant-health`
**What it does**: Per-merchant health score (hot / warm / cold) based on check-ins, active offers, unique-member count, and trend direction.
**Build**:
- File: `server/merchant-health.ts`
- `computeMerchantHealthScores()` returns array of `MerchantHealthScore`
- Score computed from: `checkIns7d`, `checkIns30d`, `checkIns90d`, `activeOffers`, `uniqueMembers`, last check-in date
- `trend`: up/stable/down based on 7d vs prior 7d
- `status`: hot (≥70), warm (40-69), cold (<40)
- `aiInsight` text generated per merchant
- `generateMerchantHealthAIInsight()` for portfolio-level Grok narrative
**Tables**: `merchants`, `check_ins`, `offers`
**Output**: Per-merchant health card with score, trend, AI insight
**WebSocket**: `merchant-health` (30s)
**Buyer**: Merchant success team + sold to merchant associations / chambers. Cost: $1,500/mo tier.

---

### 12. Data Vortex — `data-vortex`
**What it does**: Live pulse monitor — broadcasts the entire platform's BPM (events per minute) every 10 seconds. Per-ZIP pulse with heat color, status (hot/warm/cooling/cold), pulse-BPM, and recent events.
**Build**:
- File: `server/data-vortex.ts` (24 KB)
- Hardcoded `KC_ZIPS` array (27 KC ZIPs)
- `generateVortexSnapshot()` — pulls last 90 days of all activity, computes per-ZIP `ZipPulse`
- Per-ZIP fields: scanCount, quizCount, checkinCount, passportAvg, referralCount, tkcVolume, tkcBurned, usdVolumeCents, uniqueUsers, heatIndex, trend7d/30d/90d, prediction7d/30d, status, pulseBPM, pulseIntensity, pulseGlow, pulsePhase, rewardMultiplier, lastSpikeAt, recentEvents[], actionScore, tkcNeeded, heatColor (red/yellow/blue/gray), defaultProbability
- Includes a dedicated `WcSegment` for Welcoming Center visitor signups (totalSignups, signups24h, topCountries, byZip)
- `PulseAlert` types: spike, drop, milestone, prediction, pulse_reward, pulse_cooling, pulse_surge
- Cached snapshot (`getCachedSnapshot`) + broadcaster (`startVortexEngine` / `stopVortexEngine`)
- CSV export + Grok AI insight
**Tables**: every activity table (check_ins, scout_submissions, quiz_scores, tkc_transactions, referrals, receipt_scans, ar_pickups, game_activities)
**Output**: Full snapshot with `globalPulseBPM`, `crownZip`, per-ZIP pulse array
**WebSocket**: `vortex` (10s — fastest engine)
**Buyer**: Mayors, EDCs, news desks. Cost: bundled in Premium.

---

### 13. Treasure Nexus — `treasure-nexus`
**What it does**: Strategic command-bundle that fuses Vortex + Hood Heat + Flow Predictor into one weighted "nexus score" per ZIP. Used by C-suite buyers who want a single number per neighborhood.
**Build**:
- File: `server/treasure-nexus.ts` (28 KB)
- `generateNexusBundle()` — pulls vortex + flow + hood-heat outputs, computes weighted nexus score
- `simulateDrop(zip, tkcAmount)` — projects what dropping TKC into a ZIP would activate
- `filterBundleForTier(bundle, scopes[])` — slices output for tiered B2B buyers (NexusTierScope: zip allow-list, category)
- `getZipDetail(zip)` — full single-ZIP drill-down
- Cache + broadcaster + CSV/JSON export
**Tables**: aggregated from upstream engines
**Output**: `{ totalZips, globalPulseBPM, crownZip, nexusScore, perZipBundle }`
**WebSocket**: `nexus` (30s)
**Buyer**: Enterprise clients, government agencies. Cost: $30K-$50K/yr tier.

---

### 14. UrbanWealth Nexus — `urbanwealth-nexus`
**What it does**: Geo intelligence layer — every KC ZIP enriched with passport scores, civic engagement, loyalty breakdown, receipt-based purchase patterns, growth forecast, churn risk, opportunities, and population segments.
**Build**:
- File: `server/urbanwealth-nexus.ts` (36 KB)
- `K_ANON_THRESHOLD = 10` — `suppress(value)` returns null if cohort < 10
- 51 KC ZIPs in hardcoded `KC_ZIPS` + lat/lng in `ZIP_COORDS` for each
- 13 per-ZIP query functions: `getZipWealthPassport`, `getZipGeoIntelligence`, `getZipHeatmap`, `getZipTrafficTimeline`, `getZipCivicEngagement`, `getZipLoyaltyBreakdown`, `getZipReceiptIntelligence`, `getZipGrowthForecast`, `getZipChurnRisk`, `getZipOpportunities`, `getZipSegments`, `getZipComparison(zips[])`
**Tables**: every ZIP-keyed table
**Output**: Heatmap-ready GeoJSON-style array `{ count, zones: [{ zip, lat, lng, …metrics }] }`
**WebSocket**: `urbanwealth` (30s)
**Buyer**: CRE, municipal planners. Cost: bundled in Geo Intelligence package.

---

### 15. Neighborhood Retention Engine (NRE) — `neighborhood-retention`
**What it does**: Per-ZIP retention tier (Elite / High / Medium / Low) with churn/retention rates, monthly trends, top merchants, member tier breakdown, and insurer-grade risk scoring.
**Build**:
- File: `server/neighborhood-retention.ts`
- `getNREReport(targetZip?)` returns `NREReport` (engine version 1.0.0)
- `computeRetentionScore(avgDays, retention90d, churnRate30d)` = `min(100, daysFactor * retentionFactor * churnInverse * 100 * 2.5)`
- Per-ZIP: avgDaysPerMonth, retentionScore, overallTier, churnRate30d, retentionRate90d, avgStreakDays, powerUsers, monthlyTrend[], topMerchants[], tierBreakdown {elite/high/medium/low}, tierPcts
- `NRELivePulse` cached snapshot + broadcaster + CSV export + Grok AI insight
**Tables**: `users`, `check_ins`, `merchants`, `wealth_passports`
**Output**: Tiered retention bundle with insurer metrics
**WebSocket**: `nre` (30s)
**Buyer**: Insurers, community banks (CRA reporting). Cost: $4,500/mo tier.

---

### 16. Echo Vault — `echo-vault`
**What it does**: Per-member vault of every action they've taken on the platform — their personal "echo footprint." Aggregate version is sold; individual version is shown to members.
**Build**:
- File: `server/echo-vault.ts`
- Aggregate query: `COUNT(DISTINCT anon_id) AS total_users, COUNT(*) AS total_echo_actions, recent_actions (last 7d), SUM(tkc_amount), COUNT(DISTINCT zip_code)` from `platform_activities`
- `getUserEchoVault(userId)` — individual vault state with tier
- `processEchoAction(userId, actionType)` — increments the user's vault, returns delta + tier-up flag
- `generateEchoVaultAIInsight()` — Grok narrative
**Tables**: `platform_activities`
**Output**: Aggregate `{ total_users, total_echo_actions, recent_actions, total_tkc, zips_active }` OR per-user vault with tier
**WebSocket**: `echo_vault` (30s)
**Buyer**: Members (free), aggregate sold to civic orgs. Cost: package-based.

---

### 17. Conversational Intelligence — `conversational-intelligence`
**What it does**: AI assistant intent + query analysis. Powers the platform-wide chat assistant that answers natural-language questions about platform data ("What's the top ZIP for check-ins this week?"). Also tracks what members are asking so the product team can mine intents.
**Build**:
- File: `server/conversational-intelligence.ts`
- AI: `callClaudeWithHistory()` from `ai-services.ts` (Claude Sonnet primary; falls back per global cascade)
- `handleChatQuery(question, sessionId, …)` — extracts ZIP codes from question via `/\b6[0-9]{4}\b/g`, detects category, fetches relevant snapshot from DB, sends to Claude with history
- Session map (`sessions: Map<string, ConversationSession>`), 60-min TTL, cleanup interval every 5 min
- `handleLiveQABroadcast(question, answer, askedBy)` — pushes Q&A live to WS subscribers
- `getSessionHistory(sessionId)` / `clearSession(sessionId)`
- Aggregate count: active members + recent check-ins (last 30d) for buyer dashboard
**Tables**: `users`, `check_ins`, `merchant_locations`, `merchants`, `wealth_passports`, `quiz_scores`
**Output**: `{ active_members, recent_checkins, aiModel: "Claude Sonnet" }`
**WebSocket**: `conversational-intel` (on-demand)
**Buyer**: Product teams, enterprise self-service analytics. Cost: usage-priced.

---

### 18. Economic Intelligence — `economic-intelligence`
**What it does**: Macro economic pulse of KC. Computes platform-wide active members, total check-ins, avg passport score, CDFI eligibility, trend direction. Powers quarterly KC economic bulletins.
**Build**:
- File: `server/economic-intelligence.ts` (22 KB)
- `generateEconomicIntelligenceReport(opts)` — full report builder
- `buildLivePulse()` returns `EconLivePulse` (cached, broadcaster-driven)
- `getCachedPulse()` for fast reads
- `startEconIntelBroadcaster()` — broadcasts every 30s
- `generateAIEconomicNarrative(reportData)` — Grok writes the prose for the quarterly bulletin
- `formatReportForExport()` — text export for PDFs
**Tables**: `users`, `check_ins`, `wealth_passports`, `quiz_scores`, `donations`
**Output**: `{ activeMembers, totalCheckIns, passportAvg, cdfiEligible, trend }`
**WebSocket**: `economic-intel` (30s)
**Buyer**: Economists, policy think-tanks, news desks. Cost: $5,000/mo.

---

### 19. Referral Ripple Forecast — `referral-ripple-forecast`
**What it does**: Models referral-program ROI. Given a target ZIP and scout count, forecasts new users, check-ins, merchant signups over 30/90 days plus growth curves and investor-grade metrics (CAC, LTV, payback period).
**Build**:
- File: `server/referral-ripple-forecast.ts`
- `getReferralRippleForecast(targetZip?, scoutCount?)` returns `RippleForecastReport`
- Generates `RippleForecastScenario[]` — each scenario has predicted new users 30d/90d, predicted check-ins, predicted merchant signups, viral coefficient, chain depth, confidence score, and a day-by-day growth curve
- `zipIntelligence[]` — per-ZIP current state (users, scouts, check-ins, referral velocity, saturation index, opportunity score)
- `investorMetrics`: costPerAcquisition, ltv30d, ltv90d, paybackPeriodDays, monthlyGrowthRate, projectedUsersNextQuarter
- CSV export + Grok AI insight
**Tables**: `users`, `referrals`, `check_ins`, `scout_submissions`, `merchants`
**Output**: Multi-scenario forecast with VC-grade metrics
**WebSocket**: `referral-forecast` (30s)
**Buyer**: Growth teams, VCs, board investors. Cost: $3,500/mo.

---

## EXTENDED ENGINES (engines 20–29)

---

### 20. Wealth Passport — `wealth-passport`
**What it does**: Behavioral financial-identity score (0 to 1,055 points) across 5 categories: Engagement, Stability, Growth, Community, Resilience. Drives lender underwriting, member badges, and platform tier-ups.
**Build**:
- File: `server/wealth-passport.ts` (96 KB — the largest engine)
- `calculatePassport(userId, forceRefresh)` — full recompute
- `LEVEL_THRESHOLDS = [130, 260, 390, 520]` for badge tiers
- `DEFAULT_SCORE_CREDIT_MILESTONES` + `SCORE_CREDIT_MILESTONES` — TKC payouts at score thresholds
- `DEFAULT_PASSPORT_RULES` — base rule set, can be overridden via DB
- `getActiveMilestones()` / `getPassportRules()` — loaded from DB at request time
- `calculateStreakWithGrace(userId)` — streak with one-day grace per week to avoid penalizing brief gaps
- `refreshPassportAsync()` — non-blocking background refresh on hot paths
- `getAllBadgeDefinitions()` — full badge catalog
**Aggregate query** (in engine-health): `total_passports, active_passports, avg_score, top_score, distinct_levels, sum_checkins, sum_referrals, top_streak`
**Tables**: `wealth_passports`, `passport_score_events`, every action table
**Output**: Per-user passport object + aggregate platform stats
**WebSocket**: piggybacks on `command-center` / `vault`
**Buyer**: Members (free), lenders (sold via Behavioral Lending package).

---

### 21. TKC Supply Engine — `tkc-supply`
**What it does**: Real-time TKC token economics — total supply, total minted, total burned, net circulating, value index, halving multiplier, burned percentage. Public-facing via the TKC Guide.
**Build**:
- File: `server/tkc-rewards.ts` (61 KB)
- `getTotalIssuedSupply()` / `getTotalBurned()` — sum from `tkc_transactions`
- `calculateValueIndex(totalSupply, totalBurned, totalMinted)` — proprietary formula
- `getHalvingMultiplier(totalSupply, totalBurned, totalMinted)` — Bitcoin-style halving curve
- `getSupplyStats()` — composite snapshot
- `getCitySupplyStats(cityId)` — multi-city support
- `getAllCitySupplyStats()` — every Treasure Network city
**Tables**: `tkc_transactions`, `tkc_wallets`, `cities`
**Output**: `{ totalSupply, totalMinted, totalBurned, netCirculating, valueIndex, halvingMultiplier, burnedPercent }`
**WebSocket**: piggybacks on public/community channels
**Buyer**: Public + token analysts. Cost: free / public.

---

### 22. Receipt Vault Intelligence — `receipt-vault-intelligence`
**What it does**: Aggregated receipt-line spend by brand, category, and ZIP. Tells CPG brands where their products are bought, how often, and for how much. AI-parsed from real OCR'd receipts.
**Build**:
- File: `server/receipt-intelligence.ts` (45 KB)
- `brandSlug(s)` — normalizes brand names with `LOWER(REGEXP_REPLACE(brand, '[^a-zA-Z0-9]+', '', 'g'))`
- `calculateReceiptReward(totalAmount, itemCount)` — 50/100/200/500 TKC tiers based on receipt total
- `parseReceiptItems(scanId, rawText)` — Claude Sonnet parses OCR output into structured items
- `processAndStoreReceiptItems(scanId)` — full pipeline: parse → dedupe → store
- `matchAndCreditBrandOffers()` — matches sponsored Brand Offers (Fetch-style bonus TKC), idempotent per (offer_id, scan_id)
- `generateReceiptIntelligencePackage(packageType)` — tiered B2B exports
- `getReceiptIntelligenceDashboard({ wcOnly })` — admin dashboard data, optional Welcoming Center-only filter
**Tables**: `receipt_scans`, `receipt_items`, `brand_offers`, `brand_offer_redemptions`
**Output**: `{ totalScans, parsedScans, totalItems, topBrands[], topCategories[], aiModel: "Claude Sonnet" }`
**WebSocket**: piggybacks on `command-center` / `vortex`
**Buyer**: CPG brands, retail analysts. Cost: $5,000/mo.

---

### 23. Neighborhood Impact — `neighborhood-impact`
**What it does**: Civic-grade per-neighborhood reinvestment + nonprofit funding flow. Identifies top-performing vs underserved ZIPs so grant officers and city councils can prioritize.
**Build**:
- File: `server/neighborhood-impact.ts`
- `getNeighborhoodImpactData(forceRefresh)` — composite per-ZIP snapshot
- `generateAIInsights(impactData)` — Grok narrative
- `getImpactSummaryForExport(impactData)` — text export
**Tables**: `users`, `check_ins`, `merchants`, `donations`, `nonprofit_partners`
**Output**: `{ zipCodes[], totalCheckIns, totalActiveMembers, totalActiveMerchants, topPerformingZips[], underservedZips[] }`
**WebSocket**: piggybacks on civic channels
**Buyer**: Foundations, EDCs, city council. Cost: $3,000/mo.

---

### 24. Activity Tracker — `activity-tracker`
**What it does**: Real-time, anonymized event firehose. Every meaningful action is bucketed into a category, queued, batched, and broadcast to every relevant engine channel. The fan-out router for the entire intelligence layer.
**Build**:
- File: `server/activity-tracker.ts`
- 7 categories: `engagement`, `financial`, `governance`, `commerce`, `gaming`, `community`, `onboarding`
- Queue with `FLUSH_INTERVAL = 2000ms` and `MAX_BATCH = 50`
- `trackActivity({ userId, category, activityType, zipCode, merchantId, tkcAmount, usdAmountCents, metadata })` — hot-path entry point
- `ENGINE_CHANNELS` map — every activity_type explicitly enumerates which engines to broadcast to. Examples:
  - `receipt_upload` → 12 engines
  - `signup` → 12 engines
  - `referral` → 11 engines
  - `checkin` → 11 engines
  - `wealth_passport` → 7 engines
- `getActivityStats(days)` — aggregate by category for buyers
- `getActivityByZip(zip, days)` / `getEngagementDensity(days)`
**Tables**: `platform_activities` (write), every aggregate table (read)
**Output**: Array of grouped event stats by category
**WebSocket**: fans out to 19 channels
**Buyer**: Behavioral analytics buyers, internal product team. Cost: $2,500/mo.

---

### 25. Game Intelligence — `game-intelligence`
**What it does**: Per-game engagement, completion, drop-off, top-player metrics. Aggregates traditional games (`game_activities`) + AR sessions (`ar_game_sessions`).
**Build**:
- File: `server/game-intelligence.ts`
- `trackGameEvent(event)` — in-memory ring buffer of recent game events
- `getRecentGameEvents(limit=50)` — for live admin dashboard
- `generateGameIntelligenceBrief(db)` — full B2B brief (Grok-narrated)
- Aggregate query: `total_plays, unique_players, avg_score, top_score, plays_24h, plays_7d, distinct game_types` from `game_activities`; plus `sessions, players` from `ar_game_sessions`
**Tables**: `game_activities`, `ar_game_sessions`, `ar_pickups`, `ar_leaderboard`
**Output**: `{ total_plays, unique_players, game_types, top_score, plays_24h, plays_7d, ar_sessions, ar_players }`
**WebSocket**: piggybacks on `command-center` + game-specific channels
**Buyer**: Game studios, fitness brands (AR step data). Cost: $2,000/mo.

---

### 26. Scout Photo Analyzer — `scout-photo-analyzer`
**What it does**: Computer-vision analyzer for every photo submitted by Scout Army. Validates that the photo matches the claimed business/spot, AI-categorizes content (mural, empty lot, broken streetlight, etc.), assigns a quality score.
**Build**:
- File: `server/scout-photo-analyzer.ts`
- `analyzeScoutPhoto(imagePath, businessName)` — Grok Vision call to verify photo matches business
- `aiCategorizeSubmission()` — categorizes the submission type for routing (ghost spot vs nonprofit vs merchant)
- `storePhotoAsBase64(imagePath)` — fallback for when external image hosting isn't available
- AWS Rekognition is also available as a secondary vision layer
- Returns `PhotoAnalysisResult` with confidence + flags (blurry, no_storefront, duplicate)
**Aggregate query** (in engine-health): `total_submissions, with_photo, approved, pending, rejected, scouts` from `scout_submissions`
**Tables**: `scout_submissions`, `scout_bounties`, `ghost_spots`
**Output**: `{ submissions, withPhoto, approved, pending, rejected, scouts, aiModel: "Grok Vision" }`
**WebSocket**: piggybacks on scout / ghost-spot channels
**Buyer**: CRE, civic mapping orgs. Cost: per-submission tariff.

---

### 27. AI Coach — `ai-coach`
**What it does**: Personal financial coach chat — Grok-powered conversational agent that answers member financial questions ("Should I open a Roth IRA?", "How do I build credit?"). Tracks every conversation so the curriculum team can identify common knowledge gaps.
**Build**:
- File: `server/ai-coach.ts`
- `chatWithCoach()` — main chat handler, streams Grok response
- `getUserConversations(userId)` — list of past conversations
- `getConversationMessages(userId, conversationId)` — message history
- `deleteConversation(userId, conversationId)` — user-driven privacy delete
- Aggregate query: `total_conversations, unique_users, total_messages, new_7d` from `coach_conversations` joined to `coach_messages`
**Tables**: `coach_conversations`, `coach_messages`
**Output**: `{ conversations, users, messages, new_7d, aiModel: "Grok" }`
**WebSocket**: per-session
**Buyer**: Members (free), aggregate intent data sold to fintech product teams. Cost: usage-priced.

---

### 28. TreasureFlow B2B API — `treasureflow-api`
**What it does**: Unified B2B API gateway — issues, validates, and rate-limits API keys for every external partner consuming our intelligence. Per-key tier (Free / Starter / Growth / Enterprise), ZIP allow-list, and daily query cap.
**Build**:
- File: `server/treasureflow.ts`
- `generateApiKey()` — `tkc_<48-hex>` format with sha256 hash + 8-char prefix
- `hashApiKey(key)` — sha256 for storage
- `validateApiKey(keyHash)` — looks up key, checks `is_active`, `revoked_at`, `dailyLimit`, `callsToday`. Returns valid + tier + zipAllowlist + dailyLimit + callsToday OR error + statusCode
- `treasureflowAuth()` — Express middleware wrapper
- `checkZipAccess(zip, tier, allowlist)` — enforces ZIP scope per buyer's purchased package
- `logApiUsage(...)` — writes to `treasureflow_api_usage`
- Cached snapshot endpoints: `getFlowSnapshot(zip)`, `getEchoSnapshot(zip)` (5-min TTL)
- `getApiKeyStats(keyId)` — per-key usage dashboard for the buyer
- 75 supported ZIPs in `KC_ZIPS` (covers KC + KCK)
- `generateTreasureflowAIInsight(targetZip)` — Grok narrative
**Aggregate query**: `total_keys, active_keys, total_calls, calls_24h, calls_7d, distinct_consumers`
**Tables**: `treasureflow_api_keys`, `treasureflow_api_usage`
**Output**: `{ keys, active, totalCalls, calls24h, calls7d, consumers }`
**WebSocket**: `treasureflow` / per-buyer
**Buyer**: every external partner. Cost: per-call B2B tariff + tiered annual contracts.

---

### 29. Wealth Passport Score Matrix — `wealth-passport-matrix`
**What it does**: The full rule book behind the Wealth Passport — every scoring rule, every category cap, every event-type wire. Also tracks coverage (how many rules are actually firing in the last 30d, % coverage of the matrix).
**Build**:
- File: `server/wealth-passport-matrix.ts`
- `SCORE_MATRIX: ScoreRule[]` — full rule list (every rule has: category, ruleKey, label, description, pointsPerUnit, maxPoints, unit, source)
- 6 categories: `engagement`, `literacy`, `community`, `consistency`, `verification`, `deduction`
- `CATEGORY_CAPS` — per-category max contribution (Engagement 200, Literacy 200, Community 200, Consistency 200, Verification 200 → 1000 max + bonuses)
- `MAX_RAW_SCORE = 1055` (sum of caps + bonuses)
- `PASSPORT_LEVELS` — tier definitions
- Verification rules include: paid_member (15), linked_card (10), linked_bank (30), plaid_weekly (3/wk max 25), plaid_tx_verify (max 20), rent_reports (4/mo max 25), utility_bills (3/bill max 25), wp_intake_baseline (20), wp_intake_retakes (10/each max 15), wp_intake_trajectory (0.5×improvement max 15), gig_income (4/mo max 20)
- Deduction rules: engagement_gap (-10 to -60), literacy_gap (-5 to -25), community_gap (-5 to -15)
- `getMatrixCoverage(days)` — measures `rulesWithEventsLast30d / total_rules` = `coveragePercent`
**Tables**: `passport_score_events`, every action table
**Output**: `{ total_rules, categories, active_wires, coverage_percent, total_events, events_24h, events_30d, distinct_users }`
**WebSocket**: piggybacks on passport channel
**Buyer**: Internal trust + lenders (transparency artifact). Cost: bundled with Wealth Passport package.

---

## SHARED INFRASTRUCTURE (underneath every engine)

### Engine Health Monitor (`server/engine-health.ts`)
- Single registry of all 29 engines
- Per-engine `run()` invocation, latency timing, row counting, payload-bytes measurement
- Status: `ok` / `empty` / `error`
- History ring buffer per engine (last 20 runs)
- Canonical-vs-extended split: 19 flagged `canonical: true`
- Endpoints: `/api/admin/engines/health`, `/api/admin/engines/:slug`, `/api/admin/engines/:slug/export.csv`

### Activity Tracker fan-out (already covered as engine #24)
- Routes every event to the right engine channels via `ENGINE_CHANNELS` map.

### Intel-Buyer Auth (`server/intel-buyer-auth.ts`)
- Magic-link issuance (24-byte random token)
- Bcrypt password hashing
- JWT cookie sessions (`tkc_buyer`)
- Buyers live in `intel_buyers` (NOT `users`) with their own `brief` field that drives slicing

### Intel-Buyer Slicer (`server/intel-buyer-slicer.ts`)
- Filters every engine output down to the buyer's purchased slice (ZIP allow-list, merchant category, date range)
- Enforces "you bought 64110 only? you only see 64110 data" at the response layer

### B2B Marketplace (`server/b2b-marketplace.ts` + `b2b-packages-catalog.ts`)
- Stripe checkout for intelligence subscriptions
- Tiered packages (Free / Starter / Growth / Enterprise)
- Abandoned-cart alerter cron pings reps every 30 min for any cart inactive > 2h

---

## PRIVACY & ANONYMIZATION (applied to every engine)

- **K-anonymity threshold**: every engine that buckets by ZIP/cohort enforces `K_ANON_THRESHOLD = 10` (or 5 in some). Below threshold → suppressed/null.
- **`anonLabel()`** (`server/export-anonymizer.ts`): replaces real names/IDs with `Member-A1B2`-style stable hashes for every export.
- **Opt-out**: members can opt out of B2B aggregation at `/data-preferences` without losing any platform features.
- **XRPL audit hashes**: every B2B API call is hashed and logged on-chain (`logB2bApiCallToXrpl`) for tamper-proof audit.
- **CRA compliance blocks**: `buildCraComplianceBlock()` in Behavioral Lending emits CRA-grade audit trails on demand.

---

## AI MODEL ASSIGNMENT (per engine)

| AI surface | Engine(s) | Primary | Fallback chain |
|---|---|---|---|
| Conversational chat | Conversational Intelligence | Claude Sonnet | per `ai-services.ts` cascade |
| Receipt parsing | Receipt Vault Intelligence | Claude Sonnet | n/a (Claude required for OCR quality) |
| Photo vision | Scout Photo Analyzer | Grok Vision | AWS Rekognition |
| Financial coaching | AI Coach | Grok | Claude → OpenAI → OpenRouter |
| Engine narratives (every `generate*AIInsight`) | All 29 engines | Grok 3 Mini | Replit-OpenAI → OpenRouter → Anthropic Claude → deterministic local responder |
| Quarterly economic bulletins | Economic Intelligence | Grok | Claude |

---

## END-TO-END EVENT FLOW (example: a member checks in)

1. POST `/api/check-in` writes to `check_ins`.
2. `trackActivity({ userId, category: "engagement", activityType: "checkin", zipCode, merchantId, tkcAmount: 5 })`.
3. Activity Tracker queues + flushes within 2s.
4. Fan-out broadcasts to 11 engine channels: `command-center`, `hood-heat`, `vortex`, `nexus`, `nre`, `merchant-health`, `block-loyalty`, `churn`, `echo_vault`, `economic-echo`, `vault`.
5. Each engine recomputes its delta on next interval (10s for Vortex, 30s for the rest).
6. Wealth Passport Matrix records a `passport_score_events` row → score recompute.
7. Ripple Engine adds to user's ripple ledger with chain bonus + streak multiplier + active velocity boost.
8. KC Economic Echo adds the merchant tip → barista lunch downstream chain to next echo trace.
9. Receipt Vault Intelligence (if check-in came with receipt scan) parses brand/category/totals, matches Brand Offers, credits bonus TKC.
10. Subscribed B2B partners see the delta in their TreasureFlow API responses on next poll, sliced to their purchased ZIP scope.

---

## SUMMARY TABLE — ALL 29 ENGINES

| # | Engine | Slug | File | Channel | Refresh | AI | Price |
|---|---|---|---|---|---|---|---|
| 1 | Ripple Engine | ripple-engine | ripple-engine.ts | ripple | 30s | Grok | bundled |
| 2 | Ripple Forecast | ripple-forecast | ripple-forecast-api.ts | ripple-forecast | 25s cache | Grok | $3.5K/mo |
| 3 | Ghost Spot Radar | ghost-spot-radar | ghost-spot-radar.ts | ghost-spot | 30s | Grok | package |
| 4 | Hood Heat Index | hood-heat | hood-heat-index.ts | hood-heat | 30s | Grok | package |
| 5 | KC Economic Echo | kc-economic-echo | kc-economic-echo.ts | economic-echo | 30s | Grok | $5K/mo |
| 6 | Block Loyalty Index | block-loyalty | block-loyalty-index.ts | block-loyalty | 30s | Grok | $4K/mo |
| 7 | Legacy Vault | legacy-vault | legacy-vault-api.ts | legacy-vault | 30s | Grok | package |
| 8 | Flow Predictor | flow-predictor | flow-predictor.ts | flow-predictor | 30s | Grok | $5K/mo |
| 9 | Behavioral Lending | behavioral-lending | behavioral-lending.ts | lending | 30s | Grok | $25-75K/yr |
| 10 | Churn Prediction | churn-prediction | churn-prediction.ts | churn | 30s | Grok | $2.5K/mo |
| 11 | Merchant Health | merchant-health | merchant-health.ts | merchant-health | 30s | Grok | $1.5K/mo |
| 12 | Data Vortex | data-vortex | data-vortex.ts | vortex | 10s | Grok | bundled |
| 13 | Treasure Nexus | treasure-nexus | treasure-nexus.ts | nexus | 30s | Grok | $30-50K/yr |
| 14 | UrbanWealth Nexus | urbanwealth-nexus | urbanwealth-nexus.ts | urbanwealth | 30s | — | bundled |
| 15 | Neighborhood Retention | neighborhood-retention | neighborhood-retention.ts | nre | 30s | Grok | $4.5K/mo |
| 16 | Echo Vault | echo-vault | echo-vault.ts | echo_vault | 30s | Grok | package |
| 17 | Conversational Intel | conversational-intelligence | conversational-intelligence.ts | conversational-intel | on-demand | Claude | usage |
| 18 | Economic Intelligence | economic-intelligence | economic-intelligence.ts | economic-intel | 30s | Grok | $5K/mo |
| 19 | Referral Ripple Forecast | referral-ripple-forecast | referral-ripple-forecast.ts | referral-forecast | 30s | Grok | $3.5K/mo |
| 20 | Wealth Passport | wealth-passport | wealth-passport.ts | vault/command | on-write | — | bundled |
| 21 | TKC Supply Engine | tkc-supply | tkc-rewards.ts | public | on-demand | — | free |
| 22 | Receipt Vault Intelligence | receipt-vault-intelligence | receipt-intelligence.ts | command/vortex | on-scan | Claude | $5K/mo |
| 23 | Neighborhood Impact | neighborhood-impact | neighborhood-impact.ts | civic | 30s | Grok | $3K/mo |
| 24 | Activity Tracker | activity-tracker | activity-tracker.ts | (fan-out to 19) | 2s batch | — | $2.5K/mo |
| 25 | Game Intelligence | game-intelligence | game-intelligence.ts | command/games | on-demand | Grok | $2K/mo |
| 26 | Scout Photo Analyzer | scout-photo-analyzer | scout-photo-analyzer.ts | scout/ghost-spot | per-photo | Grok Vision + AWS Rekognition | per-submission |
| 27 | AI Coach | ai-coach | ai-coach.ts | per-session | per-message | Grok | usage |
| 28 | TreasureFlow B2B API | treasureflow-api | treasureflow.ts | per-buyer | per-call | Grok | per-call |
| 29 | Wealth Passport Matrix | wealth-passport-matrix | wealth-passport-matrix.ts | passport | on-event | — | bundled |

**Total**: 29 engines, ~95 distinct AI insight functions across them, 19+ WebSocket channels, full XRPL audit trail.

---

*Generated for Grok analysis. Source of truth: `server/engine-health.ts` ENGINES array. Last updated: May 3, 2026.*
